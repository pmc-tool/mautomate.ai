import {
  AuthenticatedMedusaRequest,
  MedusaResponse,
} from "@medusajs/framework/http"
import { MedusaError } from "@medusajs/framework/utils"
import { CMS_MODULE } from "../../../../../modules/cms"
import type CmsModuleService from "../../../../../modules/cms/service"
import { one, recordBlogAudit, resolveUniqueSlug } from "../_helpers"

/**
 * GET /admin/cms/blog/authors
 * List authors, paginated. Query: q?, limit, offset.
 * Response: { authors, count, limit, offset }
 */
export const GET = async (
  req: AuthenticatedMedusaRequest,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)

  const q = (req.query.q as string | undefined)?.trim()
  const limit = Math.min(Number(req.query.limit ?? 100) || 100, 200)
  const offset = Number(req.query.offset ?? 0) || 0

  const filters: Record<string, unknown> = {}
  if (q) {
    filters.$or = [
      { name: { $ilike: `%${q}%` } },
      { slug: { $ilike: `%${q}%` } },
    ]
  }

  const [authors, count] = await service.listAndCountCmsAuthors(filters, {
    take: limit,
    skip: offset,
    order: { name: "ASC" },
  })

  res.json({ authors, count, limit, offset })
}

type CreateBody = {
  name?: string
  slug?: string
  bio?: string | null
  avatar?: string | null
}

/**
 * POST /admin/cms/blog/authors
 * Create an author. Slug derived from name when omitted (422 on collision).
 * Body: { name, slug?, bio?, avatar? }   Response: { author }
 */
export const POST = async (
  req: AuthenticatedMedusaRequest<CreateBody>,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)
  const body = req.body ?? {}

  const name = (body.name ?? "").trim()
  if (!name) {
    throw new MedusaError(
      MedusaError.Types.INVALID_DATA,
      "`name` is required to create an author."
    )
  }

  const slug = await resolveUniqueSlug(
    (f) => service.listCmsAuthors(f),
    body.slug,
    name
  )

  const author = one(
    await service.createCmsAuthors({
      name,
      slug,
      bio: body.bio ?? null,
      avatar: body.avatar ?? null,
    })
  )

  await recordBlogAudit(req, service, "author.create", "author", author.id, {
    after: author,
  })

  res.status(201).json({ author })
}
