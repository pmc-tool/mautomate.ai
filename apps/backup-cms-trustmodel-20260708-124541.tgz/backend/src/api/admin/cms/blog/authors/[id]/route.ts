import {
  AuthenticatedMedusaRequest,
  MedusaResponse,
} from "@medusajs/framework/http"
import { MedusaError } from "@medusajs/framework/utils"
import { CMS_MODULE } from "../../../../../../modules/cms"
import type CmsModuleService from "../../../../../../modules/cms/service"
import { one, recordBlogAudit, resolveUniqueSlug } from "../../_helpers"

async function loadAuthor(service: CmsModuleService, id: string) {
  let author: any
  try {
    author = await service.retrieveCmsAuthor(id)
  } catch {
    author = null
  }
  if (!author) {
    throw new MedusaError(
      MedusaError.Types.NOT_FOUND,
      `Author with id "${id}" was not found.`
    )
  }
  return author
}

/**
 * GET /admin/cms/blog/authors/:id
 * Response: { author }
 */
export const GET = async (
  req: AuthenticatedMedusaRequest,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)
  const author = await loadAuthor(service, req.params.id)
  res.json({ author })
}

type UpdateBody = {
  name?: string
  slug?: string
  bio?: string | null
  avatar?: string | null
}

/**
 * PUT /admin/cms/blog/authors/:id
 * Update name/slug/bio/avatar. Slug uniqueness re-checked (excludes self).
 * Response: { author }
 */
const update = async (
  req: AuthenticatedMedusaRequest<UpdateBody>,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)
  const { id } = req.params
  const body = req.body ?? {}

  const before = await loadAuthor(service, id)

  const patch: Record<string, unknown> = { id }
  if ("name" in body) patch.name = body.name
  if ("bio" in body) patch.bio = body.bio
  if ("avatar" in body) patch.avatar = body.avatar

  if (body.slug && body.slug !== before.slug) {
    patch.slug = await resolveUniqueSlug(
      (f) => service.listCmsAuthors(f),
      body.slug,
      body.name ?? before.name,
      id
    )
  }

  const author = one(await service.updateCmsAuthors(patch))

  await recordBlogAudit(req, service, "author.update", "author", id, {
    before,
    after: author,
  })

  res.json({ author })
}

export const PUT = update
export const PATCH = update

/**
 * DELETE /admin/cms/blog/authors/:id
 * Soft-delete the author. Posts referencing this author keep their author_id
 * (the byline simply resolves to null on the store until reassigned).
 * Response: { id, object: "author", deleted: true }
 */
export const DELETE = async (
  req: AuthenticatedMedusaRequest,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)
  const { id } = req.params

  const before = await loadAuthor(service, id)

  await service.softDeleteCmsAuthors(id)

  await recordBlogAudit(req, service, "author.delete", "author", id, {
    before,
  })

  res.json({ id, object: "author", deleted: true })
}
