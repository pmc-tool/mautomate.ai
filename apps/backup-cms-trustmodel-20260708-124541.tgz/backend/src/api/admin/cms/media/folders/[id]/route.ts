import {
  AuthenticatedMedusaRequest,
  MedusaResponse,
} from "@medusajs/framework/http"
import { MedusaError } from "@medusajs/framework/utils"
import { CMS_MODULE } from "../../../../../../modules/cms"
import type CmsModuleService from "../../../../../../modules/cms/service"

function slugSegment(name: string): string {
  return (
    name
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "folder"
  )
}

/**
 * GET /admin/cms/media/folders/:id — retrieve one folder. Response: { folder }
 */
export const GET = async (
  req: AuthenticatedMedusaRequest,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)
  const folder = await service.retrieveCmsMediaFolder(req.params.id)
  res.json({ folder })
}

type UpdateBody = { name?: string }

/**
 * Rename a folder. Body: { name }. Recomputes the leaf segment of `path`
 * (keeps the parent prefix). Re-parenting / deep path cascades are out of scope
 * for the minimal Phase 2 folder support.
 * Response: { folder }
 */
const update = async (
  req: AuthenticatedMedusaRequest<UpdateBody>,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)
  const { id } = req.params

  const existing = await service.retrieveCmsMediaFolder(id)
  if (!existing) {
    throw new MedusaError(
      MedusaError.Types.NOT_FOUND,
      `Folder "${id}" was not found.`
    )
  }

  const patch: Record<string, any> = { id }
  const name = req.body?.name?.trim()
  if (name) {
    patch.name = name
    const prefix = existing.path.slice(0, existing.path.lastIndexOf("/"))
    patch.path = `${prefix}/${slugSegment(name)}`
  }

  const saved = await service.updateCmsMediaFolders(patch)
  const folder = Array.isArray(saved) ? saved[0] : saved
  res.json({ folder })
}

export const POST = update
export const PUT = update
export const PATCH = update

/**
 * DELETE /admin/cms/media/folders/:id — soft-delete a folder.
 * Minimal: does NOT cascade. Media in a deleted folder keep their folder_id;
 * the UI should treat an orphaned folder_id as root. Re-homing children/media
 * is deferred.
 * Response: { id, object: "media_folder", deleted: true }
 */
export const DELETE = async (
  req: AuthenticatedMedusaRequest,
  res: MedusaResponse
) => {
  const service: CmsModuleService = req.scope.resolve(CMS_MODULE)
  const { id } = req.params
  await service.softDeleteCmsMediaFolders(id)
  res.json({ id, object: "media_folder", deleted: true })
}
